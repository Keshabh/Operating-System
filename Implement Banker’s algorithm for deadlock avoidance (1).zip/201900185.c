/*
Algorithm
********
step 1: read number of processes, resources, and instances for each resources from user.
step 2: read the allocated, max and available instances, 
step 3: calculate need instances by each processs w.r.t each resources by need=max-allocated
step 4: initialize work=available, then loop through each process and if need of each process <= work, then work +=allocate
step 5: if work==instances allocated in the  begining, then its in safe state, else not
step 6: read extra request made by user, and check if required<=need and requird <= available also, then request can be immediately allocated, else not.
*/
#include<stdio.h>
int main()
{
    int p,r;
    int I[10];
    char c='A';
    printf("Enter the number of processes: ");
    scanf("%d",&p);
    printf("Enter the number of resources: ");
    scanf("%d",&r);
    //read all intancess for each resources
    printf("Enter the instances for each resource:\n");
    for(int i=0;i<r;i++)
    {
        printf("%c: ",c);
        scanf("%d",&I[i]);
        c++;
    }
    printf("Enter the allocated instances w.r.t each process and resource\n   ");
    c='A';
    int A[p][r];
    for(int i=0;i<r;i++)
     {
         printf("%c ",c);
         c++;
     }
    printf("\n");
    for(int i=0;i<p;i++)
    {	 	  	 	  	     	    	     	 	
        printf("P%d ",i);
        for(int j=0;j<r;j++)
        {
            scanf("%d",&A[i][j]);
         
        }
    }
    
    printf("\n\nEnter the maximum instances w.r.t each process and resource\n   ");
    c='A';
    int M[p][r];
    for(int i=0;i<r;i++)
     {
         printf("%c ",c);
         c++;
     }
    printf("\n");
    for(int i=0;i<p;i++)
    {
        printf("P%d ",i);
        for(int j=0;j<r;j++)
        {
            scanf("%d",&M[i][j]);
         
        }
    }
    
    printf("\n\nEnter the available instances for each resource\n");
    c='A';
    int available[r],work[r];
    for(int i=0;i<r;i++)
     {
         printf("%c ",c);
         c++;
     }
     printf("\n");
     for(int i=0;i<r;i++)
     {	 	  	 	  	     	    	     	 	
       scanf("%d",&available[i]);
       work[i]=available[i];
     }
    //find and print need matrix
    printf("\n\nNeed matrix: \n");
    c='A';
    printf("   ");
    for(int i=0;i<r;i++)
     {
         printf("%c ",c);
         c++;
     }
    int need[p][r];
    for(int i=0;i<p;i++)
    {
        printf("\nP%d ",i);
        for(int j=0;j<r;j++)
        {
            need[i][j]=M[i][j]-A[i][j];
            printf("%d ",need[i][j]);
        }
    }
    
    //use safety algo to check if all process exist in the safe state 
    int index=0,count=0,mark=1,jk=0;
    //make an array for indicating whether process[i] is added in the sequence or not
    int indicate[r];
    
    //1 indicates the process is added
    while (1)
    {
        if(indicate[index]!=1)
        {
            mark=1;
        for(int i=0;i<r;i++)
        {	 	  	 	  	     	    	     	 	
            if (need[index][i]>work[i])
             mark=2;
        }
        if (mark==1) //it satisfies for need<=work
        {
            
            //work +=allocate
            for(int i=0;i<r;i++)
            {
                work[i]+=A[index][i];
                
            }
            
            indicate[index]=1;
            count++;
        }
        }
        
        index++;
        if(index==p)
         {index=0;
         jk++;
         }
       
        //if work==I then its in safe state, but if previous work value and cur value is still same, then 
        //unsafe state
        for(int i=0;i<r;i++)
         {
             if(work[i]==I[i])
              mark=1;
             else
             {
              mark=2;
              break;
             }
              
         }	 	  	 	  	     	    	     	 	
        if (mark==1)
         {
             printf("\n\nIt is in safe state.\n\n");
             break;
         }
        if (jk>p)
        {
         printf("\n\nIt is in unsafe state.\n\n");
         break;
        }
    }
    
    //read the request for any process and check if immediate allocation is allowed or not
    int a;
    printf("Which process number from 0th index needs immediate location: ");
    scanf("%d",&a);
    int req[r];
    printf("Enter the instances needed by your process for each resource: ");
    for(int i=0;i<r;i++)
    {
        scanf("%d",&req[i]);
    }
    
    //check if immediate allocation is allowed or not
    //check if req<=need of ath positioned process
    mark=1;
    for(int i=0;i<r;i++)
    {
        if(req[i]<=need[a][i])
         mark=1;
        else
         mark=2;
    }
    if (mark==1) //check if req<=available
    {
        for(int i=0;i<r;i++)
        {	 	  	 	  	     	    	     	 	
            if(req[i]<=available[i])
             mark=1;
            else
             mark=2;
        }
    }
    if(mark==1)
    {
     printf("This request can be immediately allocated.");
    }
    else
     printf("This request can not be immediately allocated.");
    
}



/*
IP/OP
*****

Enter the number of processes: 5
Enter the number of resources: 3
Enter the instances for each resource:
A: 10
B: 5
C: 7
Enter the allocated instances w.r.t each process and resource
   A B C 
P0 0 1 0
P1 2 0 0
P2 3 0 2
P3 2 1 1
P4 0 0 2


Enter the maximum instances w.r.t each process and resource
   A B C 
P0 7 5 3
P1 3 2 2
P2 9 0 2
P3 2 2 2
P4 4 3 3


Enter the available instances for each resource
A B C 
3 3 2


Need matrix: 
   A B C 
P0 7 4 3 
P1 1 2 2 
P2 6 0 0 
P3 0 1 1 
P4 4 3 1 

It is in safe state.

Which process number from 0th index needs immediate location: 1
Enter the instances needed by your process for each resource: 1 0 2
This request can be immediately allocated.
*/	 	  	 	  	     	    	     	 	
