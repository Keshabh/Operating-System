/*
Regisration number: 201900185

Algorithm:
**********
step 1: define 2 char array to read source file and dest file name from user.
step 2: create 2 file pointer fptr1 for reading source file and fptr2 to write in dest file
step 3: open source in read mode and open dest file in write mode
step 4: check if source file exists or not, if not then, display the message "file doesn't exist or file error!" and end the program
step 5: run while loop, while reading each character from source file using fgetc function till it encounters end of file(EOF).
step 6 while reading each caharcter, copy the character in the variable ch.
step 7: write ch in dest file using fputc function.
step 8: close both the file using fclose

Input/Ouput
**********
Enter source file-name: source.txt

Enter destination file-name: dest.txt

Copied each content from source.text to dest.txt
Now You can Check it from your dest.text file

*/

#include<stdio.h>
#include <stdlib.h>

int main()
{
    char s[50],d[50];
    printf("Enter source file-name: ");
    scanf("%s",s);
    printf("\nEnter destination file-name: ");
    scanf("%s",d);
    
    //create 2 file pointer, fptr1 points to source.txt and fptr2 points to dest.txt
    FILE *fptr1,*fptr2;
    //lets open source.txt to read from it using fptr1
    fptr1 = fopen("source.txt","r");
    //lets open dest.txt to write in it using fptr2
    fptr2 = fopen("dest.txt","w");
    
    //check if source fill exists or not
    if(fptr1==NULL)
     {	 	  	 	  	     	    	     	 	
         printf("File doesnot exist / There is an error in opening the source file.");
         return 1;
     }
    //create a charcter variable store each charcater from source file
    char ch;
    
    //lets read source file character by character
    while((ch=fgetc(fptr1))!=EOF)
    {
        //lets write each charcter into dest file
        fputc(ch,fptr2);
    }

    printf("\nCopied each content from source.text to dest.txt\nNow You can Check it from your dest.text file");
    //lest close both the file
    fclose(fptr1);
    fclose(fptr2);
    
}



