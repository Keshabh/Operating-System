/*
Algortihm
*********
step 1: initialize mutex with 1, full=0, empty=5(buffer size), x=0
step 2: declare producer and consumer function
step 3: In main, declare wait and signal function to control producer and cosumer w.r.t buffer size.
step 4: read user choice for 1. producing, 2. consuming or 3. exiting the program
step 5: if choice is 1: then check if buffer is empty and mutext is 1, if yes call producer function else buffer is full
step 6: if chocie is 2: then check if there is something still there in buffer and mutex is 1, call consumer function , else buffer is empty
step 7: if chocie is 3: exit the program
step 8: define wait function: decrement mutex value by 1 and define signal fucntion: decrements mutex value by 1
step 9: define producer function, initalize the values in wait, signal and empty with the help of wait and signal function, incrememt x(item number) by 1
        display item produced, and call signal function to change val of mutex.
step 10: define consumer function, initalize the values in wait, signal and empty with the help of wait and signal function, incrememt x(item number) by 1
        display item consumed, and call signal function to change val of mutex.
*/
#include<stdio.h>
#include<stdlib.h>
 
int mutex=1,full=0,empty=5,x=0;

void producer();
void consumer();

int main()
{
    int n;
    int wait(int);
    int signal(int);
    printf("Press\n1.Producer\n2.Consumer\n3.Exit");
    while(1)
    {
        printf("\nEnter your choice:");
        scanf("%d",&n);
        switch(n)
        {
            
        case 1: 
        if((mutex==1)&&(empty!=0)) 
           producer(); 
        else 
           printf("\nBuffer is full!!");
        break;
        
        case 2:
        if((mutex==1)&&(full!=0))
           consumer();
        else
           printf("\nBuffer is empty!!");
        break;
        
        case 3: exit(0); break;
        
        default:printf("\nInvalid Choice.");
    }	 	  	 	  	     	    	     	 	
}
return 0;
}
 
int wait(int s)
{
    return (--s);
}
 
int signal(int s)
{
    return(++s);
}
 
void producer()
{
    mutex=wait(mutex);
    full=signal(full);
    empty=wait(empty);
    x++;
    printf("\nProducer produces the item %d\n",x);
    mutex=signal(mutex);
}
 
void consumer()
{
    mutex=wait(mutex);
    full=wait(full);
    empty=signal(empty);
    printf("\nConsumer consumes item %d\n",x);
    x--;
    mutex=signal(mutex);
}

/*
IP/OP
*******
Press
1.Producer
2.Consumer
3.Exit
Enter your choice:1

Producer produces the item 1

Enter your choice:1

Producer produces the item 2

Enter your choice:4

Invalid Choice.
Enter your choice:2

Consumer consumes item 2

Enter your choice:1

Producer produces the item 2

Enter your choice:1

Producer produces the item 3

Enter your choice:1

Producer produces the item 4

Enter your choice:1

Producer produces the item 5

Enter your choice:1

Buffer is full!!
Enter your choice:2

Consumer consumes item 5

Enter your choice:2

Consumer consumes item 4

Enter your choice:2

Consumer consumes item 3

Enter your choice:1

Producer produces the item 3

Enter your choice:2

Consumer consumes item 3

Enter your choice:3

*/	 	  	 	  	     	    	     	 	
