/*
Algorithm:
**********
step 1: declare variables such as n,sum,i,j   and read the number of jobs we have from the user.
step 2: declare arrays such as job[], exec[], priority[], wait[], turn_around[]
step 3: for each job, read their execution time and priority from the user and store it in the exec[] and priority[] array.
step 4: to execute the job on the basis of priority, sort the task and its whole data.
step 5: display gantt chart 
step 6: itertate for n times, and calculate waiting time and turn-aroun time for each process and store it in wait[] and turn_around[]
step 7: display waiting time and turn around time.
stwp 8: display its average waiting time and avg turn around time.
*/
#include<stdio.h>
int main()
{
    int n,i,j,t;
    int sum=0;
    /*FILE *fptr1,*fptr2;
    fptr1=fopen("input.txt","w+");
    fptr2=fopen("output.txt","w+");*/
    printf("Enter the number of processes: ");
    scanf("%d",&n);
    float avg_wait, avg_turn_around;
    int job[n],exec[n],priority[n],wait[n],turn_around[n];
    
    for(i=0;i<n;i++)
    {
      printf("\nProcess: P%d\n",i+1);
      job[i] = i+1;
      printf("Enter execution time: ");
      scanf("%d",&exec[i]);
      printf("Enter priority: ");
      scanf("%d",&priority[i]);
    }
    
    /*fprintf(fptr1,"Process Name\tExecution Time\tPriority\n");*/
    for(i=0;i<n;i++)
    {	 	  	 	  	     	    	     	 	
        /*fprintf(fptr1,"P%d      \t\t    %d        \t\t  %d\n",job[i],exec[i],priority[i]);*/
    }
    
    for(i=0;i<n;i++)
    {
        for (j=0;j<n-i-1;j++)
        {
    
            if(priority[j]>priority[j+1])
            {
    
                t=priority[j];
                priority[j]=priority[j+1];
                priority[j+1]=t;
                
                t=job[j];
                job[j]=job[j+1];
                job[j+1]=t;
                
                t=exec[j];
                exec[j]=exec[j+1];
                exec[j+1]=t;
            }
        }
    }
    
    
    printf("\nGantt Chart: \n");
    /*fprintf(fptr2,"\nGantt Chart: \n");*/
    for(i=0;i<n;i++)
    {
        printf("|---P%d---|",job[i]);
        /*fprintf(fptr2,"|---P%d---|",job[i]);*/
    }
    printf("\n");
    printf("0");
    /*fprintf(fptr2,"\n");
    fprintf(fptr2,"0");*/
    
    for(i=0;i<n;i++)
    {	 	  	 	  	     	    	     	 	
        sum=sum+ exec[i];
        wait[i]=sum-exec[i]; 
        turn_around[i]=sum;
        printf("        %d",sum);
        /*fprintf(fptr2,"        %d",sum);*/
    }
    
    
    printf("\n\nProcess   Waiting Time   Turn-AroundTime\n");
    /*fprintf(fptr2,"\n\nProcess   Waiting Time   Turn-AroundTime\n");*/
    for(i=0;i<n;i++)
    {
        printf("P%d\t\t%d\t\t%d\n",job[i],wait[i],turn_around[i]);
        /*fprintf(fptr2,"P%d         %d        %d\n",job[i],wait[i],turn_around[i]);*/
    }
    
    
    for(i=0;i<n;i++)
    {
        avg_wait+=wait[i];
        avg_turn_around+=turn_around[i];
    }
    
    printf("\nAverage Waiting Time: %.2f",avg_wait/n);
    printf("\nAverage Turn around Time: %.2f",avg_turn_around/n);
    /*fprintf(fptr2,"\nAverage Waiting Time: %.2f",avg_wait/n);
    fprintf(fptr2,"\nAverage Turn around Time: %.2f",avg_turn_around/n);*/
}

/*
Sample 1:
********
Input
-------
Process Name	Execution Time	Priority
P1      		    10        		  2
P2      		    5        		  0
P3      		    8        		  1

Ouput
-------

Gantt Chart: 
|---P2---||---P3---||---P1---|
0        5        13        23

Process   Waiting Time   Turn-AroundTime
P2         0        5
P3         5        8
P1         13        10

Average Waiting Time: 6.00
Average Turn around Time: 13.67

Sample 2:
*********
Input
-----
Process Name	Execution Time	Priority
P1      		    10        		  3
P2      		    1        		  1
P3      		    2        		  4
P4      		    1        		  5
P5      		    5        		  2

Ouput
-------

Gantt Chart: 
|---P2---||---P5---||---P1---||---P3---||---P4---|
0        1        6        16        18        19

Process   Waiting Time   Turn-AroundTime
P2         0        1
P5         1        6
P1         6        16
P3         16        18
P4         18        19

Average Waiting Time: 8.20
Average Turn around Time: 12.00
*/
	 	  	 	  	     	    	     	 	
