/*
Reg.no: 201900185

Algorithm
*********
step 1: declare arrays such as jobs[] for storing job_id, arrt[] for arrival time, bt[] for burst time, temp[] for storing burst time as a temporary copy, wait[] to store waiting time.
step 2: declare variables such as complete( marks the completion of tasks), n (number of tasks), index(to store id of selected task),tme(store each unit cycle.),
step 3: read the value of n from user
step 4: iterate in the loop n times, and read the value of bt[] and arrt[] for each process from user
step 5: iterate in the loop n times and initialze each value of wait to be 0, and copy bt in temp.
step 6: run infinte loop till complete!=n (when all the task is completed). and each time loop runs , time increments by 1 unit.
step 7: within the loop, iterate through the for loop n times to traverse through each job to select the shortest remaining time job whose arrival time is less than current time, 
        and whose burst time>0.
step 8: the index of job satisfying step 7 is selected, and its burst time is reduced by 1.
step 9: if burst time of selected job is 0, then increment complete by 1, and store the wait time of that job in wait[i];
step 10: display gantt chart
step 11: iterate through the wait[] array and display the waiting time of each and every process.
step 12: sum up all the wait time in step 9, and display the avergae value of it.
*/

#include<stdio.h>
int main()
{
    /*FILE *fptr1,*fptr2;*/
    int n;
    printf("Enter the number of jobs: ");
    scanf("%d",&n);
    
    int jobs[n],bt[n],arrt[n],wait[n],temp[n];
    int i,complete=0,min=999999,index,tme=0,end,prev=99999;
    float sum=0,avg;
    
    /*
    fptr1=fopen("input.txt","w+");
    fptr2=fopen("output.txt","w+");
    */
    
    for(i=0;i<n;i++)
    {	 	  	 	  	     	    	     	 	
        printf("\nProcess : J[%d]\n",i+1);
      /* fprintf(fptr1,"\nProcess : J[%d]\n",i+1); */
        jobs[i]=i+1;
        printf("Enter burst time: ");
     /* fprintf(fptr1,"\nBurst time: "); */
        scanf("%d",&bt[i]);
     /* fprintf(fptr1," = %d",bt[i]); */
        printf("Enter arrival time: ");
    /*  fprintf(fptr1,"\narrival time: "); */
        scanf("%d",&arrt[i]);
     /* fprintf(fptr1," = %d",arrt[i]); */

    }
    for(i=0;i<n;i++)
    {
       wait[i]=0;
       temp[i]=bt[i];
    }
    
    printf("\nGantt Chart\n");
   /* fprintf(fptr2,"\nGantt Chart\n"); */
   
    while(complete!=n)
    {
        min=999999;
        for(i=0;i<n;i++)
        {
            if(arrt[i]<=tme && bt[i]<min && bt[i]>0)
            {
                index=i;
                min=bt[i];
            }
        }    

        bt[index]--;

        if(bt[index]==0)
            {	 	  	 	  	     	    	     	 	
                complete++;
                end = tme + 1;
                wait[index]=end-arrt[index]-temp[index];
            }
        
        if(prev!=index)
        {
            printf("|---J%d---|",index+1);
        /*  fprintf(fptr2,"|---J%d---|",index+1); */
        }
        prev=index;
        
        tme++;
    }
    
    printf("\n\nWaiting time of each process:\n");
    /*fprintf(fptr2,"\n\nWaiting time of each process:\n"); */
    for(i=0;i<n;i++)
    {
      printf("J[%d] = %d\n",i+1,wait[i]);
   /*fprintf(fptr2,"J[%d] = %d\n",i+1,wait[i]); */
    }
    
    for(i=0;i<n;i++)
      sum+=wait[i];
    avg=sum/n;

    printf("\nAverage waiting time for each process: %.2f",avg);
    /*fprintf(fptr2,"\nAverage waiting time for each process: %.2f",avg); */
    
    
}

/*
INPUT.TXT
*********

Process : J[1]

Burst time:  = 7
arrival time:  = 0
Process : J[2]

Burst time:  = 4
arrival time:  = 2
Process : J[3]

Burst time:  = 1
arrival time:  = 4
Process : J[4]

Burst time:  = 4
arrival time:  = 5

OUTPUT.TXT
**********

Gantt Chart
|---J1---||---J2---||---J3---||---J2---||---J4---||---J1---|

Waiting time of each process:
J[1] = 9
J[2] = 1
J[3] = 0
J[4] = 2

Average waiting time for each process: 3.00


INPUT2.TXT
**********

Process : J[1]

Burst time:  = 15
arrival time:  = 0
Process : J[2]

Burst time:  = 8
arrival time:  = 5
Process : J[3]

Burst time:  = 10
arrival time:  = 10
Process : J[4]

Burst time:  = 3
arrival time:  = 15

OUTPUT2.TXT
**********

Gantt Chart
|---J1---||---J2---||---J1---||---J4---||---J1---||---J3---|

Waiting time of each process:
J[1] = 11
J[2] = 0
J[3] = 16
J[4] = 0

Average waiting time for each process: 6.75

*/	 	  	 	  	     	    	     	 	
