/*
Algoruthm:
**********
step1: create a bubble sort function to sort the arr
step 2: create a binary_search funcion to search an element on the sorted arr
step 3: create a child_process function to perform the child task.
step 4: in main: read array values from user and store it in array "arr".
step 5: call bubble sort function to sort function
step 6: display sorted array.
step 7: read the element to be searched.
step 8: if fork==0, run the child process and search the element via child task.


IP/OP
*****
Enter size of the array: 5
Enter values in integer array
5
4
3
2
1
SORTED ARRAY
1 2 3 4 5 
Enter element to be searched: 3
The element is at position 3


*/

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>


void bubble_sort (int arr [], int count)
{	 	  	 	  	     	    	     	 	
    int i, j,temp;
    for (i = 0; i < count; i++)
        for (j = 0; j < count-i-1; j++)
            if (arr[j] > arr[j+1])
            {
                temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
}


int binarySearch(int arr[], int left, int right, int num)
{
    while (left <= right)
    {
        int mid = left + (right - left) / 2;
        if (arr[mid] == num)
            return mid;
        else if (arr[mid] < num)
            left = mid + 1;
        else
            right = mid - 1;
    }
    return -1;
}

void child_process (int arr[], int size, int search)
{
    int val = binarySearch(arr, 0, size - 1, search); 

    if (val == -1)
        printf("\nThe element does not exist");
    else
        printf("\nThe element is at position %d", val + 1);

    printf("\n");
}	 	  	 	  	     	    	     	 	


int main()
{

  
    int size,i,search;
    int arr[30];
    
    printf("Enter size of the array: ");
    scanf("%d", &size);
    printf("\nEnter values in integer array\n");
    for (i = 0; i < size; i++)
        scanf("%d", &arr[i]);

    bubble_sort(arr, size); 

    printf("SORTED ARRAY\n");
    for (i = 0; i < size; i++)
        printf("%d ", arr[i]);
    
    printf ("\nEnter element to be searched: ");
    scanf ("%d", &search);
    
    if (fork() == 0)
    {
        
        child_process (arr, size, search);
    }						  
	
    return 0;
}

	 	  	 	  	     	    	     	 	
