/*
step 1: include headeer files such as pthread.h for multi-threading, semaphore.h for semaphores, unistd.h for posix. 
step 2: declare global varible i, and sem_t len
step 3: define void * even thread, which prints all the even numbers, increments i and uses sem_post for unlocking the semaphore referenced.
step 4: define void * odd thread, which prints all the even numbers, increments i and uses sem_post for unlocking the semaphore referenced.
step 5: in main, declare pthread_t threads id t1 and t2.
step 6: create threads with id's t1 and even function and t2 with odd function
step 7: use pthread_join for t1 and t2 to terminate.
*/


#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdlib.h>  
#include <unistd.h>

int i=0;
sem_t len;

void * even()
{
    i=0;
    while(1)
    {   
        sleep(1);
        printf("Even: %d\n",i);
        i+=1;
        sem_post(&len);
    }}
    
void * odd()
{
    i=0;
    while(1)
    {
        sleep(1);
        printf("Odd: %d\n",i);
        i+=1;
        sem_post(&len);
        
    }}	 	  	 	  	     	    	     	 	
    
int main()
{
    
    pthread_t t1, t2;
    pthread_create(&t1,NULL,even,NULL);
    pthread_create(&t2,NULL,odd,NULL);
    pthread_join(t1,NULL);
    pthread_join(t2,NULL);
    return 0;
}

/*
Ouput:
*********
Even: 0
Odd: 1
Even: 2
Odd: 3
Even: 4
Odd: 5
Even: 6
Odd: 7
Even: 8
Odd: 9
Even: 10
Odd: 11
Even: 12
Odd: 13
Even: 14
Odd: 15
Even: 16
Odd: 17
Even: 18
Odd: 19
Even: 20
Odd: 21
Even: 22
Odd: 23

*/	 	  	 	  	     	    	     	 	
