/*
Reg.no: 201900185

Algorithm
*********
step 1: declare two file pointers fptr1, fptr2 for writing in 2 files: input.txt and output.txt
step 2: read the number of jobs from user
step 3: read jobs and its exeution time from the user in an array exe[n] for execution time and jobs[n] for storing the order of jobs
step 4: while taking input from user, write input in the file input.txt
step 5: according to shortest job first, sort the jobs w.r.t to its execution time and sort its job order too.
step 6: display gantt chart in the console as well as write it in the output.txt file
step 7: iterate in the loop , and sum up the waiting time of each processes, sum[i] will be waiting time of Job J[i].
step 8: display each job's waiting time as well as write in the output file.
step 9: calculate the avg waiting time and display it in the terminal and writre the ouput in the file too.
*/

#include<stdio.h>
int main()
{
    /*
    //file pointer fptr1, fptr2 for input and output file.
    FILE *fptr1,*fptr2;
    fptr1=fopen("input.txt","w+");
    fptr2=fopen("output.txt","w+");
    */
    
    int n;
    //read the number of jobs from the user
    printf("Enter the number of jobs: ");
    scanf("%d",&n);
    int jobs[n],exe[n];
    
    printf("\nProcess Name\tExecution time");
    for(int i=0;i<n;i++)
    {
    printf("\nJ%d\t  \t",i+1);
    scanf("%d",&exe[i]);
    jobs[i]=i+1;
    
    //fprintf(fptr1,"J%d = %d\n",i+1,exe[i]);
        
    }	 	  	 	  	     	    	     	 	
    
    //sort the execution time and job order.
    for(int i=0;i<n-1;i++)
    {
        for(int j=0;j<n-i-1;j++)
        {
            if (exe[j]>exe[j+1])
            {
                //swap execution time
                int t=exe[j];
                exe[j]=exe[j+1];
                exe[j+1]=t;
                //swap job orde too in jobs array
                int k=jobs[j];
                jobs[j]=jobs[j+1];
                jobs[j+1]=k;
            }
        }
    }
    
    //display
      
  printf("\n**Output**\n\nGantt Chart:\n");
  //fprintf(fptr2,"\n**Output**\n\nGantt Chart:\n");
  for(int i=0;i<n;i++)
  {
  printf("|-------J%d-------",jobs[i]);
  //fprintf(fptr2,"|------J%d------",jobs[i]);
  }
  printf("|\n");
  //fprintf(fptr2,"|\n");
  
  int sum=0;
  for(int i=0;i<=n;i++)
  {
  printf("%d\t\t",sum);
  //fprintf(fptr2,"%d\t      ",sum);
  sum=sum+exe[i];
  }	 	  	 	  	     	    	     	 	
  printf("\n\nWaiting time for each process:\n");
  //fprintf(fptr2,"\n\nWaiting time for each process:\n");
  
  sum=0;
  int add=0;
  for(int i=0;i<n;i++)
  {
  add=add+sum;
  printf("J%d = %d\n",jobs[i],sum);
  //fprintf(fptr2,"J%d = %d\n",jobs[i],sum);
  sum=sum+exe[i];
  }
  
  printf("\nAverage Waiting time: %d/4 = %.2f\n",add,add/4.0);
  //fprintf(fptr2,"\nAverage Waiting time: %d/4 = %.2f\n",add,add/4.0);
  
}

/*
Input.txt
-----------
J1 = 15
J2 = 8
J3 = 10
J4 = 3

Ouptut.txt
-----------

Gantt Chart:
|------J4------|------J2------|------J3------|------J1------|
0	      3	      11	      21	      36	      

Waiting time for each process:
J4 = 0
J2 = 3
J3 = 11
J1 = 21

Average Waiting time: 35/4 = 8.75
/*

/*
Another input:

Input.txt
----------
J1 = 2
J2 = 8
J3 = 1
J4 = 6
J5 = 4
J6 = 9

Output.txt
----------

Gantt Chart:
|------J3------|------J1------|------J5------|------J4------|------J2------|------J6------|
0	      1	      3	      7	      13	      21	      30	      

Waiting time for each process:
J3 = 0
J1 = 1
J5 = 3
J4 = 7
J2 = 13
J6 = 21

Average Waiting time: 45/4 = 11.25
*/
	 	  	 	  	     	    	     	 	
