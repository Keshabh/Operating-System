/*
Algorithm:
**********
step 1:declare mutex and wait semaphore, and a readercount to store the number of reader process we have
step 2: declare four threads, 2 reader threads and 2 writer threads
step 3: in main function, initailize mutex and wait semaphore with sem_init
step 4: run the loop in main, and create 2 reader threads i.e reader 1 and reader 2 and then create 2 thread for writer i.e writer 1 and writer 2
step 5: define readder and writer function, 
step 6: in reader function, display previous value of mutex, then block the current semaphore, increment readercount to ensure one reader is there in critical section,
       if readercount is atleast 1, then block semaphore, and then unlock the semaphore, then display mutex returned by reader, 
       now if reader ends, decrement reader by 1 ,, and if readercount is 0 unlock the semaphore.
step 7: define writer function, and display the value in writer function, and unlock the semaphore.
*/

#include<stdio.h>
#include<pthread.h>
#include<semaphore.h>

sem_t mutex;
sem_t wait;
int readercount=0;
pthread_t reader1,reader2,writer1,writer2;
void *reader(void *);
void *writer(void *);
main()
{
sem_init(&mutex,0,1);
sem_init(&wait,0,1);
while(1)
{
pthread_create(&reader1,NULL,reader,"1");
pthread_create(&reader2,NULL,reader,"2");
pthread_create(&writer1,NULL,writer,"1");
pthread_create(&writer2,NULL,writer,"2");
}
}
void *reader(void *p)
{	 	  	 	  	     	    	     	 	
printf("prevoius value %dn",mutex);
sem_wait(&mutex);
printf("Mutex acquired by reader %dn",mutex);
readercount++;
if(readercount==1) sem_wait(&wait);
sem_post(&mutex);
printf("Mutex returned by reader %dn",mutex);
printf("Reader %s is Readingn",p);
//sleep(3);
sem_wait(&mutex);
printf("Reader %s Completed Readingn",p);
readercount--;
if(readercount==0) sem_post(&wait);
sem_post(&mutex);
}

void *writer(void *p)
{
printf("Writer is Waiting n");
sem_wait(&wait);
printf("Writer %s is writingn ",p);
sem_post(&wait);
//sleep(2);
}

/*
Input/Ouput
**********
Writer is Waiting nWriter 2 is writingn Writer is Waiting nWriter 2 is writingn prevoius value 0
nMutex acquired by reader 0nMutex returned by reader 0
nReader 1 is ReadingnReader 1 Completed Readingnprevoius value 0
nMutex acquired by reader 0nMutex returned by reader 0
nReader 2 is ReadingnReader 2 Completed ReadingnWriter is Waiting nWriter 1 is writingn Writer is Waiting n
Writer 2 is writingn prevoius value 0nMutex acquired by reader 0
nMutex returned by reader 0nReader 1 is ReadingnReader 1 Completed Readingnprevoius value 0
nMutex acquired by reader 0nMutex returned by reader 0
nReader 1 is ReadingnReader 1 Completed Readingnprevoius value 0nMutex acquired by reader 0
nMutex returned by reader 0
*/
	 	  	 	  	     	    	     	 	
