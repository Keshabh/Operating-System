/*
REg.no: 201900185

Algorithm:
**********
step 1: declare all the variables like count, end_time, complete, avg, sum,n,q and arrays such as wait[n], burst[n],temp[n], gantt_job[],gantt_exec[].
step 2:  read number of jobs i.e n and quantum value i.e q from user.
step 3: read the value of burst time of each n jobs from user and store it in burst[n] array and copy the values in temp.
step 4: run the loop until complete !=n i.e my whole jobs are completed.
step 5: within the loop,itertate over each task again and again like first come first service.
step 6: if burst[i] >0 , then it has 2 cases, I. burst time of job is greater than quantum value and II. if burst time is smaller than quantum.
step 7: if burst[i]>q, then decrement q from the burst[i], and update end_time+=q, and check if burst time has become 0 for that job , increment complete by 1.
step 8: if burst[i]<q, then make burst[i]=0 and update end_time+=burst[i], and increment complete by 1. 
        update wait[i]=end_time- burst[i]
step 9: in both step 7 and 8, store the value of job_id and execution time in gantt_job[] and gantt_exec[].
step 10: display gantt chart with the help of gantt_job[] and gantt_exec[] array.
step 11: display waitng time of each process and then display the average waiting time of each process.

*/

#include<stdio.h>
int main()
{
    int n,q,count=0,end_time=0,i,complete=0;
    float sum,avg;
    int gantt_job[100]={0},gantt_exec[100]={0};
    printf("Enter the number of jobs: ");
    scanf("%d",&n);
    printf("Enter the Quantum(Q) Value: ");
    scanf("%d",&q);
    /*
    FILE *fptr1,*fptr2;
    fptr1=fopen("input.txt","w+");
    fptr2=fopen("output.txt","w+");
    */
    /*
    fprintf(fptr1,"\nNumber of jobs: %d",n);
    fprintf(fptr1,"\nQuantum Value: %d",q);
    */
    int burst[n],temp[n],wait[n];
    printf("Jobs\t\tBurst time\n\n");
    /*fprintf(fptr1,"\nJobs\t\tBurst time\n\n");*/
    for(i=0;i<n;i++)
    {	 	  	 	  	     	    	     	 	
        printf("J[%d]\t\t",i+1);
        scanf("%d",&burst[i]);
        /*fprintf(fptr1,"J[%d] = %d\n",i+1,burst[i]);*/
        temp[i]=burst[i];
    }
    
     while (complete!=n)
     {
        
        for(i=0;i<n;i++)
        {
            if (burst[i]>0)
            {
                if(burst[i]>=q)
                {
                    burst[i]-=q;
                    gantt_job[count]=i+1;
                    gantt_exec[count]=q;
                    count++;
                    end_time+=q;
                    if(burst[i]==0)
                    {
                      complete++;
                      wait[i]=end_time-temp[i];
                    }
                }
                else
                {
                    gantt_job[count]=i+1;
                    gantt_exec[count]=burst[i];
                    end_time+=burst[i];
                    burst[i]=0;
                    wait[i]=end_time-temp[i];
                    complete++;
                    count++;
                }	 	  	 	  	     	    	     	 	
            }
        }
     }
     
     printf("\n\nGantt Chart\n");
     /*fprintf(fptr2,"\n\nGantt Chart\n");*/
     for(i=0;i<count;i++)
     {
         printf("|--J%d--|",gantt_job[i]);
         /*fprintf(fptr2,"|--J%d--|",gantt_job[i]);*/
     }
     printf("\n");
     /*fprintf(fptr2,"\n");*/
     for(i=0;i<count;i++)
     {
         printf("   %d   ",gantt_exec[i]);
         /*fprintf(fptr2,"   %d   ",gantt_exec[i]);*/
     }
     
     
     printf("\n\nWaiting time of each process: \n");
     /*fprintf(fptr2,"\n\nWaiting time of each process: \n");*/
    for(i=0;i<n;i++)
    {
        sum+=wait[i];   
        printf("J%d = %d\n",i+1,wait[i]);
        /*fprintf(fptr2,"J%d = %d\n",i+1,wait[i]);*/
    }
    

    printf("\n\nThe average waiting time of each process is: %.2f",sum/n);
    /*fprintf(fptr2,"\n\nThe average waiting time of each process is: %.2f",sum/n);*/
    
}

/*
INPUT.txt
**********

Number of jobs: 4
Quantum Value: 20
Jobs		Burst time

J[1] = 53
J[2] = 17
J[3] = 68
J[4] = 24

OUPUT.txt
**********
|--J1--||--J2--||--J3--||--J4--||--J1--||--J3--||--J4--||--J1--||--J3--||--J3--|
   20      17      20      20      20      20      4      13      20      8   

Waiting time of each process: 
J1 = 81
J2 = 20
J3 = 94
J4 = 97


The average waiting time of each process is: 73.00

*/	 	  	 	  	     	    	     	 	
