/*
Reg.no: 201900185

Algorithm
*********
step 1: declare two file pointers fptr1, fptr2 for writing in 2 files: input.txt and output.txt
step 2: read jobs and its exeution time from the user in an array
step 3: while taking input from user, write input in the file input.txt
step 4: display gantt chart in the console as well as write it in the output.txt file
step 5: iterate in the loop , and sum up the waiting time of each processes, sum[i] will be waiting time of Job J[i].
step 6: display each job's waiting time as well as write in the output file.
step 7: calculate the avg waiting time and display it in the terminal and writre the ouput in the file too.

Input.txt
*********
J1 = 15
J2 = 8
J3 = 10
J4 = 3

Output.txt
***********
Gantt Chart:
|------J1------|------J2------|------J3------|------J4------|
0	      15	      23	      33	      36	      

Waiting time for each process:
J1 = 0
J2 = 15
J3 = 23
J4 = 33

Average Waiting time: 71/4 = 17.75

*/

#include<stdio.h>
int main()
{	 	  	 	  	     	    	     	 	
  //file pointer fptr1, fptr2 for input and output file.
  FILE *fptr1,*fptr2;
  fptr1=fopen("input.txt","w");
  fptr2=fopen("output.txt","w");
  //make an array to store four jobs
  int arr[4];
  //read execution time from user
  printf("\n**INPUT**\n");
  printf("\nProcess Name\tExecution time");
  for(int i=0;i<4;i++)
  {
    printf("\nJ%d\t  \t",i+1);
    scanf("%d",&arr[i]);
    //write these inputs into a file too i.e input.txt
    fprintf(fptr1,"J%d = %d\n",i+1,arr[i]);
  }
  
  //lets print the ouput in console
  
  printf("\n**Output**\n\nGantt Chart:\n");
  fprintf(fptr2,"\n**Output**\n\nGantt Chart:\n");
  for(int i=0;i<4;i++)
  {
  printf("|------J%d------",i+1);
  fprintf(fptr2,"|------J%d------",i+1);
  }
  printf("|\n");
  fprintf(fptr2,"|\n");
  
  int sum=0;
  for(int i=0;i<5;i++)
  {
  printf("%d\t      ",sum);
  fprintf(fptr2,"%d\t      ",sum);
  sum=sum+arr[i];
  }	 	  	 	  	     	    	     	 	
  printf("\n\nWaiting time for each process:\n");
  fprintf(fptr2,"\n\nWaiting time for each process:\n");
  
  sum=0;
  int add=0;
  for(int i=0;i<4;i++)
  {
  add=add+sum;
  printf("J%d = %d\n",i+1,sum);
  fprintf(fptr2,"J%d = %d\n",i+1,sum);
  sum=sum+arr[i];
  }
  
  printf("\nAverage Waiting time: %d/4 = %.2f\n",add,add/4.0);
  fprintf(fptr2,"\nAverage Waiting time: %d/4 = %.2f\n",add,add/4.0); 
  
  
  
}